export interface EstabCentroCusto {
    cod_empresa: string;
    cod_estab: string;
    nom_abrev: string;
    cod_ccusto: string;
    des_tit_ctbl: string;
  }